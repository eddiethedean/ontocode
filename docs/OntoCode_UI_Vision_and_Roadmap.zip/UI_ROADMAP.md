# OntoCode UX Roadmap

# 0.1 Foundations
- Create global WorkspaceStore
- Current Focus model
- Unified message protocol
- Remove duplicated state

# 0.2 Layout
- Three-pane responsive layout
- Dockable bottom panel
- Persistent tabs
- Breadcrumbs
- Navigation history

# 0.3 Explorer
- Fast virtualized tree
- Favorites
- Recent entities
- Workspace search

# 0.4 Inspector
- Card-based overview
- Overview/Hierarchy/Relationships/Annotations/History tabs
- Inline editing

# 0.5 Search
- Spotlight-style search
- Search entities, docs, queries, git, diagnostics

# 0.6 Graph
- Interactive graph workspace
- Pinning
- Layouts
- Filtering
- Saved views

# 0.7 Query
- SQL workbench
- Autocomplete
- Saved queries
- Split table/graph/results

# 0.8 Reasoning
- Live diagnostics
- Build-style reasoning
- Suggested fixes

# 0.9 AI
- Context-aware actions
- Explain
- Refactor
- Generate docs
- Repair modeling issues

# 0.10 Collaboration
- Semantic diffs
- Semantic pull requests
- Timeline/history
- Review workflows

# 1.0 OntoStudio
- Shared React UI
- VS Code extension
- Desktop application
- Common OntoCore backend
