# OntoCode UI Vision

## Vision

OntoCode should not be "Protégé inside VS Code." It should become the first modern IDE for ontology engineering.

### Core Principles

1. Context over windows
- The interface revolves around a single **Current Focus** (entity).
- Every view reacts automatically to the current focus.

2. Workflows over tools
- Optimize for Explore, Edit, Validate, Refactor, Review, Document—not individual panels.

3. Progressive disclosure
- Beginners see a simple workspace.
- Advanced semantic features appear only when needed.

4. Workspace-first
- Treat ontologies as living semantic workspaces instead of collections of files.

## Workspace Layout

- Global Search / Command Palette
- Explorer
- Central Workspace
- Inspector
- Bottom utility dock (Problems, Graph, Query, AI, Git, Terminal)

No dedicated "Graph Mode" or "Reasoner Mode". Everything stays synchronized.

## Current Focus

Selecting an entity updates:
- Explorer
- Inspector
- Graph
- Reasoner
- Documentation
- References
- Git History
- AI Suggestions

## UX Goals

- Inline editing instead of dialogs
- Universal search
- Rich entity cards
- Contextual actions
- Live graph
- AI throughout the UI
- Semantic pull requests
- Time-travel history
- IDE-quality navigation

## Long-Term Goal

Create the JetBrains experience for ontology engineering:
cohesive, fast, discoverable, AI-assisted, and centered on semantic understanding rather than files.
